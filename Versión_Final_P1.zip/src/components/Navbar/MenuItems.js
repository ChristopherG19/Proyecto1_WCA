export const MenuItems = [
  {
    title: 'Información',
    url: '#',
    acName: 'ContainerOp',
    cName: 'fa-solid fa-circle-info',
  },
  {
    title: 'Competiciones',
    url: '#',
    acName: 'ContainerOp',
    cName: 'fa-solid fa-cube',
  },
  {
    title: 'Resultados',
    url: '#',
    acName: 'ContainerOp',
    cName: 'fa-solid fa-list',
  },
  {
    title: 'Reglamento',
    url: '#',
    acName: 'ContainerOp',
    cName: 'fa-solid fa-book',
  },
  {
    title: 'Find us',
    url: '#',
    acName: 'ContainerOp',
    cName: 'fa-solid fa-paper-plane',
  },
  {
    title: 'Foro',
    url: '#',
    acName: 'ContainerOp',
    cName: 'fa-solid fa-comments',
  },
]
